﻿namespace Teamviewer
{
    partial class mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.refresh = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.txtip = new System.Windows.Forms.TextBox();
            this.txtport = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.raccses = new System.Windows.Forms.RadioButton();
            this.ftransfer = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtpasswd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(73, 82);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(24, 21);
            this.refresh.TabIndex = 0;
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(273, 205);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(115, 23);
            this.connect.TabIndex = 1;
            this.connect.Text = "Connect To Partner";
            this.connect.UseVisualStyleBackColor = true;
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // txtip
            // 
            this.txtip.Location = new System.Drawing.Point(49, 53);
            this.txtip.Name = "txtip";
            this.txtip.Size = new System.Drawing.Size(87, 20);
            this.txtip.TabIndex = 2;
            // 
            // txtport
            // 
            this.txtport.Location = new System.Drawing.Point(152, 53);
            this.txtport.Name = "txtport";
            this.txtport.Size = new System.Drawing.Size(35, 20);
            this.txtport.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = ":";
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(103, 82);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(43, 20);
            this.txtpass.TabIndex = 5;
            // 
            // raccses
            // 
            this.raccses.AutoSize = true;
            this.raccses.Checked = true;
            this.raccses.Location = new System.Drawing.Point(273, 136);
            this.raccses.Name = "raccses";
            this.raccses.Size = new System.Drawing.Size(100, 17);
            this.raccses.TabIndex = 6;
            this.raccses.TabStop = true;
            this.raccses.Text = "Remote Accses";
            this.raccses.UseVisualStyleBackColor = true;
            // 
            // ftransfer
            // 
            this.ftransfer.AutoSize = true;
            this.ftransfer.Location = new System.Drawing.Point(273, 160);
            this.ftransfer.Name = "ftransfer";
            this.ftransfer.Size = new System.Drawing.Size(83, 17);
            this.ftransfer.TabIndex = 7;
            this.ftransfer.TabStop = true;
            this.ftransfer.Text = "File Transfer";
            this.ftransfer.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(273, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 8;
            // 
            // txtpasswd
            // 
            this.txtpasswd.Location = new System.Drawing.Point(294, 110);
            this.txtpasswd.Name = "txtpasswd";
            this.txtpasswd.Size = new System.Drawing.Size(100, 20);
            this.txtpasswd.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "هلا هون الاي بي ولبورت تبع السيرفير";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "كلمه سر للسيرفر";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(219, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(204, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "هون بأدخل ايبي ولبورت مشان انشئ اتصال";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(219, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "هون كلمه السر";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(294, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "هدول حاليا منظر";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(220, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "ملاحظه البرنامج تقريبا شغال علا الهابي سناريو";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(100, 248);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(243, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "كل مشكله بتصير لازم يتسكر البرنامج ويرجع يتشغل  ";
            // 
            // mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 270);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtpasswd);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.ftransfer);
            this.Controls.Add(this.raccses);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtport);
            this.Controls.Add(this.txtip);
            this.Controls.Add(this.connect);
            this.Controls.Add(this.refresh);
            this.Name = "mainform";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button refresh;
        private System.Windows.Forms.Button connect;
        private System.Windows.Forms.TextBox txtip;
        private System.Windows.Forms.TextBox txtport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.RadioButton raccses;
        private System.Windows.Forms.RadioButton ftransfer;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtpasswd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

