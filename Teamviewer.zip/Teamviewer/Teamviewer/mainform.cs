﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using SocketClass;
using System.Text.RegularExpressions;


namespace Teamviewer
{




    public partial class mainform : Form
    {

        sockets server = new sockets();
        sockets client = new sockets();
       
        
        static string password;
        
        public mainform()
        {
            InitializeComponent();
        }

        private void connect_Click(object sender, EventArgs e)
        {
            
            string ip_port = comboBox1.Text;
            if (comboBox1.Text == "") //check not null
                MessageBox.Show("please enter id to connect to"); //print message is null
            else
            {
                Match match = Regex.Match(ip_port, @"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{4,5}\b");//reqular expretion

                if (match.Success) 
                {

                    
                    comboBox1.Items.Add(comboBox1.Text);
                    string [] address=comboBox1.Text.Split(':');
                    string ip = address[0];
                    int port =Convert.ToInt32( address[1]);
                        bool check=client.CreateClientImg(ip, port, txtpasswd.Text);
                        if (!check)
                        {
                            MessageBox.Show("wrong password");
                            client.Dispose();///this doesn't works read it
                            return;

                        }
                        
                        Desktop dForm = new Desktop(new object[3]{client,ip,port});
                        dForm.Show();

                        
                }
                else
                    MessageBox.Show("Doesn't match an ID  \nFor Example: 127.0.0.1:4423");
            }
            
        }
        ServerChat schat = new ServerChat();
        private void resignpassword()
        {
            Random r = new Random();
            txtpass.Text = r.Next(111111, 999999).ToString();
            password = txtpass.Text;//         /  this will asign new password
            server.ResignPassword(txtpass.Text);
        }
        public void send_recv()
        {
            server.BeginSendImg(sockets.ServerImage);
            //
            //server.BeginRecvMsg(s,s.recv, sockets.ServerEvent);
            server.BeginRecvMsg(this, recv, sockets.ServerEvent);

        }
        public void recv(string ms)
        {
            schat.recv(ms);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            Random r = new Random();   // \
            int port=r.Next(4123,4897);// /    this will asign port
            resignpassword();
            server.Create_Server(port, password,this,send_recv);
            
            
            
            string[] ip_port = server.Getip_port();
            txtip.Text = ip_port[0].ToString();
            txtport.Text = ip_port[1].ToString();
            comboBox1.Text = ip_port[0] + ":" + ip_port[1];//this just for make it simple you can delete it

            
            
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            resignpassword();
        }
    }
}
