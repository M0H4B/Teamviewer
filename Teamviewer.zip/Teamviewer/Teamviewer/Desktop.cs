﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using SocketClass;


namespace Teamviewer
{
    public partial class Desktop : Form
    {
        Chat Cht = new Chat();
      static  sockets imgclient;
      sockets client = new sockets();
      string ip;
      int port;
      
        public Desktop(object o)
        {
            object[] objs = (object[])o;
            sockets client = (sockets)objs[0];
            ip = (string)objs[1];
            port = (int)objs[2];
           
            imgclient = client;
            InitializeComponent();
        }

        private void Desktop_Load(object sender, EventArgs e)
        {

            imgclient.BeginReceiveImg(this, setimage, sockets.ClientImage);
            bool b=client.CreateClient(ip,port);
            imgclient.BeginRecvMsg(this, recevmsg, sockets.ClientEvent);
            
        }
        
        public void recevmsg(string msg)
        {
            //play sound
            Cht.recevmsg(msg);
           
            
        }
        public void setimage(Image img)
        {
            pictureBox1.Image = img;
        }

        private void Desktop_FormClosing(object sender, FormClosingEventArgs e)
        {
            imgclient.Dispose();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            
           if (e.Button == System.Windows.Forms.MouseButtons.Left)
                client.send_mesg("Left|3", sockets.ClientEvent);
            else if (e.Button == System.Windows.Forms.MouseButtons.Right)
                client.send_mesg("Right|3", sockets.ClientEvent);
            
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            int x = e.X;
            int y = e.Y;
            string msg=x.ToString() + ":" + y.ToString() + "|1";
            client.send_mesg(msg, sockets.ClientEvent);
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
                client.send_mesg("Left|2", sockets.ClientEvent);
            else if (e.Button == System.Windows.Forms.MouseButtons.Right)
                client.send_mesg("Right|2", sockets.ClientEvent);
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cht.Show();
        }

        private void Desktop_KeyDown(object sender, KeyEventArgs e)
        {
            
            client.send_mesg(e.KeyValue.ToString() + "|5",sockets.ClientEvent);
        }

        private void Desktop_KeyUp(object sender, KeyEventArgs e)
        {
           
            
        }
    }
}
