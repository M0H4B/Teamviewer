﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SocketClass;
namespace Teamviewer
{
    public partial class ServerChat : Form
    {
        sockets server = new sockets();
        public ServerChat()
        {
           
            
            InitializeComponent();
        }

        private void ServerChat_Load(object sender, EventArgs e)
        {

        }
        public void recv(string msg)
        {
            //play sound
            this.Show();
            listBox1.Items.Add("(Target): " + msg);
            
        }
       
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (!(textBox1.Text == ""))
            {
                server.send_mesg(textBox1.Text + "|4", sockets.ServerEvent);
                listBox1.Items.Add("(You): " + textBox1.Text);
                textBox1.Text = "";

            }
        }
    }
}
