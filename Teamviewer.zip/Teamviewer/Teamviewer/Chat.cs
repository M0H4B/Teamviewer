﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SocketClass;
namespace Teamviewer
{
    public partial class Chat : Form
    {
        sockets client = new sockets();
       
        public Chat()
        {
            InitializeComponent();
        }
        public  void recevmsg(string msg)
        {
            
            listBox1.Items.Add("(Target): " + msg);
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!(textBox1.Text==""))
            {
                listBox1.Items.Add("(You): "+textBox1.Text);
                client.send_mesg(textBox1.Text + "|4", sockets.ClientEvent);
                textBox1.Text = "";
                return;
            }

        }

        private void Chat_Load(object sender, EventArgs e)
        {
            
        }
    }
}
