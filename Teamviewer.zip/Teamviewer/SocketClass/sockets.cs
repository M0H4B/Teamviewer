﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;



namespace SocketClass
{
    [ComVisible(true)]
    public class sockets
    {
        //winapi
        
        [DllImport("user32.dll")]
        static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
      
        [Flags]
        public enum MouseEventFlags
        {
            LEFTDOWN = 0x00000002,
            LEFTUP = 0x00000004,
            MIDDLEDOWN = 0x00000020,
            MIDDLEUP = 0x00000040,
            MOVE = 0x00000001,
            ABSOLUTE = 0x00008000,
            RIGHTDOWN = 0x00000008,
            RIGHTUP = 0x00000010
        }

        [DllImport("user32.dll")]
        static extern uint keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);
        public static void KeyDown(System.Windows.Forms.Keys key)
        {
            keybd_event((byte)key, 0x45, 0, 0);
        }
        public enum KeyEventFlags
        { 
            KEYEVENTF_EXTENDEDKEY = 0x0001,
            KEYEVENTF_KEYUP = 0x0002
        }

       


        
        public static Socket ClientEvent { set { client2server = value; } get { return client2server; } }
        public static Socket ClientImage { set { clientImg = value; } get { return clientImg; } }
        public static Socket ServerImage { set { listclient[0] = value; } get { return listclient[0]; } }
        public static Socket ServerEvent { set { listclient[1] = value; } get { return listclient[1]; } }
        static int port = 0;
        static string ipaddress = "";
        byte[] MSG = new byte[1024];
        static Socket[] listclient = new Socket[2];
        Socket server = null;
        static string password;
        static Socket client2server = null;
        static Socket clientImg = null;
        static IPEndPoint Ip_port;
        byte[] bfr = new byte[9999999];//16384
        static int i = 0;
        public delegate void pointer_beginsend();
        public void Create_Server(int Port,string pass,Form main,pointer_beginsend beginsend)
        {
            
                port = Port;
                password = pass;
                string host = Dns.GetHostName();//this will return computer name 
                IPHostEntry ip = Dns.GetHostByName(host);//this will return ip of the host
                ipaddress = ip.AddressList[0].ToString();
                IPEndPoint ip_port = new IPEndPoint(ip.AddressList[0], port);
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                server.Bind(ip_port);
                server.Listen(-1);
                Ip_port = ip_port;
                Thread t = new Thread(accept);
                t.Start(new object[2]{main,beginsend});
           
        }

        public void accept(object b)
        {
            object[] objs = (object[])b;
            Form main = (Form)objs[0];
            pointer_beginsend beginsend = (pointer_beginsend)objs[1];

            listclient[i] = server.Accept();
            bool check = verfiypassword(listclient[i]);
            if (!check)
            { listclient[i].Close(); }
            i++;

            listclient[i] = server.Accept();
            main.Invoke(beginsend);

        }
            
        

        public void send_mesg(string msg,Socket sock)
        {
            MSG = UnicodeEncoding.ASCII.GetBytes(msg);
            sock.Send(MSG);
        }
        public delegate void funcpoint(string mes);
        public  void BeginRecvMsg(Form main,funcpoint f,Socket sock)
        {
            MSG = new byte[1024];
            sock.BeginReceive(MSG, 0, MSG.Length, SocketFlags.None, new AsyncCallback(msgrecvcallback),new object[3]{main,f,sock});
        }
        private  void msgrecvcallback(IAsyncResult iar)
        {
            object[] objs = (object[])iar.AsyncState;
            Form main = (Form)objs[0];
            funcpoint f = (funcpoint)objs[1];
            Socket s = (Socket)objs[2];
            
            

            int size = s.EndReceive(iar);
            if (size > 2)
            {
                
                String Mesg = UnicodeEncoding.ASCII.GetString(MSG);
                int id = int.Parse(Mesg.Substring(Mesg.IndexOf('|') + 1, 1));

                if (id == 1)//mouse move
                {
                    int x;
                    int y;
                    try
                    {
                        x = int.Parse(Mesg.Substring(0, Mesg.IndexOf(':')));
                        y = int.Parse(Mesg.Substring(Mesg.IndexOf(':') + 1, Mesg.IndexOf('|') - Mesg.IndexOf(':') - 1));
                        Cursor.Position = new Point(x, y);
                    }
                    catch
                    { }

                }
                else if (id == 2)//mouse up
                {
                    try
                    {
                        int X = Cursor.Position.X;
                        int Y = Cursor.Position.Y;
                        string a = Mesg.Substring(0, Mesg.IndexOf('|'));
                        if (a == "Left")
                            mouse_event((int)(MouseEventFlags.LEFTUP), X, Y, 0, 0);

                        else if (a == "Right")
                            mouse_event((int)(MouseEventFlags.RIGHTUP), X, Y, 0, 0);
                    }
                    catch
                    { }
                }
                else if (id == 3)//mouse down
                {

                    int X = Cursor.Position.X;
                    int Y = Cursor.Position.Y;
                    try
                    {
                        string a = Mesg.Substring(0, Mesg.IndexOf('|'));
                        if (a == "Left")
                            mouse_event((int)(MouseEventFlags.LEFTDOWN), X, Y, 0, 0);

                        else if (a == "Right")
                            mouse_event((int)(MouseEventFlags.RIGHTDOWN), X, Y, 0, 0);

                    }
                    catch { }
                }
                else if (id == 4)//message
                {
                    try
                    {
                        main.Invoke(f, Mesg.Substring(0, Mesg.IndexOf('|')));
                    }
                    catch { }
                }
                
                else if (id == 5)//key down
                {
                    try
                    {

                        byte tusKodu = byte.Parse(Mesg.Substring(0, Mesg.IndexOf(':')));
                        KeyDown(System.Windows.Forms.Keys.A);
                       // keybd_event(0x45, 0x45, (uint)KeyEventFlags.KEYEVENTF_EXTENDEDKEY, 0);
                        //keybd_event(, 0x45, (uint)KeyEventFlags.KEYEVENTF_EXTENDEDKEY, 0);
                    }
                    catch (Exception why)
                    {MessageBox.Show(why.Message); 
                    }
                }
                
            }

            s.BeginReceive(MSG, 0, MSG.Length, SocketFlags.None, new AsyncCallback(msgrecvcallback), new object[3] { main, f, s });
        
        }
        public  void BeginSendImg(Socket sock)
        {
            Byte[] sendBytes = sockets.grab_Desktop();
            sock.BeginSend(sendBytes, 0, sendBytes.Length, SocketFlags.None, new AsyncCallback(SendImgCallback), sock);
        }
        private  void SendImgCallback(IAsyncResult ar)
        {
            Socket u = (Socket)ar.AsyncState;
            int size = u.EndSend(ar);
            Byte[] sendBytes = sockets.grab_Desktop();
            u.BeginSend(sendBytes, 0, sendBytes.Length, SocketFlags.None, new AsyncCallback(SendImgCallback), u);

        }










        public bool CreateClientImg(string ip, int port, string pass)
        {
            IPEndPoint ip_port = new IPEndPoint(IPAddress.Parse(ip), port);
            clientImg = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            clientImg.Connect(ip_port);
            bool check = sendpassword(pass, clientImg);
            if (check)
                return true;
            return false;
           

        }
        public bool CreateClient(string ip, int port)
        {
            IPEndPoint ip_port = new IPEndPoint(IPAddress.Parse(ip), port);
            client2server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            client2server.Connect(ip_port);
            return true;


        }
       public void Dispose()
        {
            i = 0;
            clientImg.Close();
            clientImg.Dispose();
            GC.SuppressFinalize(clientImg);
           
        }



        public void BeginReceiveImg(Form main, point2func p,Socket sock)
        {
            clientImg.BeginReceive(bfr, 0, bfr.Length, SocketFlags.None, new AsyncCallback(receiveimgcallback), new object[3] { main, p, clientImg });
           
        }
       
        private void receiveimgcallback(IAsyncResult iar)
        {
            object[] objs = (object[])iar.AsyncState;
            Form main = (Form)objs[0];
            point2func p = (point2func)objs[1];
            Socket sock = (Socket)objs[2];
            int size = sock.EndReceive(iar);
            if (size > 1024)
            {
                try{
                    MemoryStream ms = new MemoryStream(bfr);
                    Image img = Bitmap.FromStream(ms);
                    main.Invoke(p, img);
                   }
                catch (Exception why)
                {
                    
                }
                
                        
                
            }

            sock.BeginReceive(bfr, 0, bfr.Length, SocketFlags.None, new AsyncCallback(receiveimgcallback), new object[3] { main, p, sock });

        }
       
        public delegate void point2func(Image img);


        public string[] Getip_port()
        {

            string[] ip_port = new string[2];
            ip_port[0] = ipaddress;
            ip_port[1] = port.ToString();
            return ip_port;

        }
        public void ResignPassword(string pa) { password = pa; }
        private static byte[] grab_Desktop()
        {
            Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            //Bitmap bmp = new Bitmap(10, 10);
            Graphics gr = Graphics.FromImage(bmp);
            gr.CopyFromScreen(0, 0, 0, 0, new Size(bmp.Width, bmp.Height));
            MemoryStream ms = new MemoryStream();

            bmp.Save(ms, ImageFormat.Png);
            return ms.GetBuffer();
        }
        private bool sendpassword(string pass, Socket sock)
        {
            byte[] b = UnicodeEncoding.ASCII.GetBytes(pass);
            sock.Send(b);
            b = new byte[8];
            sock.Receive(b);

            string w = UnicodeEncoding.ASCII.GetString(b);

            if (!(Convert.ToInt32(w) == 1))
            {

                return false;
            }
            return true;
        }
        private bool verfiypassword(Socket soc)
        {
            byte[] passwordbuffer = new byte[1024];

            soc.Receive(passwordbuffer);
            string rec = UnicodeEncoding.ASCII.GetString(passwordbuffer);

            int y = Convert.ToInt32(rec);
            int x = Convert.ToInt32(password);
            if (x == y)
            {
                soc.Send(UnicodeEncoding.ASCII.GetBytes("1"));
                return true;
            }
            else
            {
                soc.Send(UnicodeEncoding.ASCII.GetBytes("0"));
                return false;
            }



        }
    }
}
